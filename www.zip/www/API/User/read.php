<?php
ob_clean(); // Clean the output buffer
header("Access-Control-Allow-Origin: *");
header("Content-Type: application/json; charset=UTF-8");

include_once '../config/Database.php';
include_once '../class/Users.php';

$database = new Database();
$db = $database->getConnection();
$items = new Users($db);
$stmt = $items->getUsers();
$itemCount = $stmt->rowCount();

if ($itemCount > 0) {
    $userArr = array();
    $userArr["body"] = array();
    $userArr["itemCount"] = $itemCount;

    while ($row = $stmt->fetch(PDO::FETCH_ASSOC)) {
        extract($row);
        $e = array(
            "id_user" => $id_user,
            "firstname" => $firstname,
            "name" => $name,
            "mail" => $mail
        );
        array_push($userArr["body"], $e);
    }

    echo json_encode($userArr);
} else {
    http_response_code(404);
    echo json_encode(array("message" => "No record found."));
}
?>

<?php
header("Access-Control-Allow-Origin: *");
header("Access-Control-Allow-Methods: PUT, GET, POST, DELETE");
header("Access-Control-Allow-Headers: Origin, X-Requested-With, Content-Type, Accept");
header("Content-Type: application/json");

session_start();
ini_set('display_errors', 1);
ini_set('display_startup_errors', 1);
error_reporting(E_ALL);
if ($_SERVER["REQUEST_METHOD"] === "POST") {

    include '../config/Database.php';

    if (isset($_POST['mail'])) {
        $mailconnect = htmlspecialchars($_POST['mail']);
        $passwordconnect = $_POST['passwd'];

        if (!empty($mailconnect) && !empty($passwordconnect)) {
            $db = new Database();
            $pdo = $db->getConnection();

            $stmt = $pdo->prepare("SELECT * FROM admin WHERE mail = :mail");
            $stmt->bindParam(':mail', $mailconnect);

            if ($stmt->execute()) {
                $recover = $stmt->fetch(PDO::FETCH_ASSOC);

                if ($recover !== false && password_verify($passwordconnect, $recover['password'])) {
                    $_SESSION['admin'] = true;
                    setcookie("admin_session", session_id(), time() + 86400, "/");
                    echo json_encode(['status' => 'success', 'message' => 'Connecté']);
                } else {
                    echo json_encode(['status' => 'error', 'message' => 'Identifiants incorrects']);
                }
            } else {
                echo json_encode(['status' => 'error', 'message' => 'Erreur lors de l\'exécution de la requête']);
            }
        } else {
            echo json_encode(['status' => 'error', 'message' => 'Paramètre \'mail\' non défini']);
        }
    } else {
        echo "Paramètre 'mail' non défini";
    }
}
?>

<?php
session_start();
include '../config/Database.php';
include_once '../Admin/traitement_connexion.php';

if (isset($_SESSION['mail'])) {// Vérifier si la variable de session de l'admin existe
    
    // L'administrateur est connecté
    $response = array("authenticated" => true, "mail" => $_SESSION['mail']);
    echo json_encode($response);

} else {
    // Aucune session d'administrateur n'est trouvée
    $response = array("authenticated" => false);
    echo json_encode($response);
}
?>
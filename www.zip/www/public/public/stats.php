<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Statistiques de Réponses</title>
    <style>
        body {
            font-family: Arial, sans-serif;
            margin: 20px;
        }
        .question {
            font-size: 18px;
            font-weight: bold;
            margin-bottom: 10px;
        }
        .answer-container {
            margin-bottom: 20px;
        }
        .answer {
            display: flex;
            justify-content: space-between;
            align-items: center;
            margin-bottom: 5px;
        }
        .bar {
            height: 20px;
            background-color: #eee;
            border-radius: 5px;
            overflow: hidden;
        }
        .fill-bar {
            height: 100%;
            background-color: #4caf50;
            border-radius: 5px;
        }
        .percentage {
            margin-left: 10px;
        }
    </style>
</head>
<body>
    <?php
    // Récupérer les données du script PHP
    include_once '../API/Admin/traitement_stats.php'; // Assurez-vous que le chemin est correct
    $data = json_decode($result, true);

    // Vérifier si la question a été trouvée
    if (isset($data["question"])) {
        $question = $data["question"];
        $answers = $data["answers"];

        // Afficher la question
        echo '<div class="question">' . $question . '</div>';

        // Afficher les réponses avec la barre de remplissage
        foreach ($answers as $answer) {
            echo '<div class="answer-container">';
            echo '<div class="answer">';
            echo '<div>' . $answer["answer"] . '</div>';
            echo '<div class="bar">';
            echo '<div class="fill-bar" style="width: ' . $answer["percentage"] . '%;"></div>';
            echo '</div>';
            echo '<div class="percentage">' . $answer["percentage"] . '%</div>';
            echo '</div>';
            echo '</div>';
        }
    } else {
        echo '<p>La question n\'a pas pu être trouvée.</p>';
    }
    ?>
</body>
</html>

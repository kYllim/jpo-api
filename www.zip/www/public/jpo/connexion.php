<?php session_start();

if ($_SERVER["REQUEST_METHOD"] == "POST") {


$pdo = new PDO('mysql:host=localhost;dbname=jpo', 'root', '');

if (!$pdo){
    echo"non";
}

if(isset($_POST['login'])) { //isset vérifie si la clé 'login' existe dans la bdd

    //récupération des informations du formulaire
    $loginconnect = htmlspecialchars($_POST['login']);
    $passwdconnect = $_POST['passwd'];

    if(!empty($loginconnect) && !empty($passwdconnect)){
        $requser = $pdo->prepare("SELECT * FROM users WHERE login = :login"); //la requête est prête à être éxécutée
        $requser->bindParam(':login', $loginconnect); //liaison du paramètre :login à $loginconnect
        $requser->execute(); //éxécution de la requête
        $recover = $requser->fetch(); //récuperation de la ligne users dans un tableau
        
        
        if($recover !== false){ //si l'utilisateur existe
            if(password_verify($passwdconnect, $recover['passwd'])){
                echo"connecté";
            }
        }

    }
}


}
?>

<!DOCTYPE html>
<html lang="fr">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>JPO IUT de Meaux - Connexion</title>
</head>
<body>
<div id="contener">
            <div>
            <h2>  </h2>
                <form method="POST" action="">
                   
                                <input type="text" placeholder="Login" name="login" id="login">
                                <input type="password" placeholder="Mot de passe" name="passwd" id="passwd">
                                <input type="submit" value="Se connecter">   
                </form>

           
            </div>
    </div>
</body>
</html>

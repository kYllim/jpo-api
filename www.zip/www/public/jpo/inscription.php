<?php 
if ($_SERVER["REQUEST_METHOD"] == "POST") {

    $login = $_POST["login"];
    $passwd = $_POST["mdp"];
    $confirmpsswd = $_POST["confirmmdp"];
    // $statut = $_POST["statut"];

//vérifier que aucun n'est vide
if (!empty($login) && !empty($passwd)){

    //verification de la correspondance des mots de passe
    if($passwd == $confirmpsswd){

        $pdo = new PDO('mysql:host=localhost;dbname=jpo', 'root', '');
    

     // Vérifier si le login n'existe pas dans la base de données
    $query = $pdo->query("SELECT * FROM users WHERE login='$login'");

    $rowcount = $query->rowCount();
    if ($rowcount == 0){
        $request = $pdo->prepare("INSERT INTO users (login, passwd) VALUES (:login, :passwd)");

    // Liaison des paramètres, les variables seront liées parametre :non :pre... (sécurisation contre injection slq)
        $request->bindParam(':login', $login);
        // $request->bindParam(':statut', $statut);
        $hashedPassword = password_hash($passwd, PASSWORD_DEFAULT);
        $request->bindParam(':passwd', $hashedPassword);

        // Exécution de la requête
        $start = $request->execute();
        // header('Location: login.php');

        if ($start){
            echo "Enregistrement réussi";
        }
        else{
            echo "erreur d'enregistrement";
        }
     
}
else{
    echo "Ce login existe déjà";
}
}
else{
echo "Votre mot de passe ne correspond pas";
}
}
else{
    echo "Remplissez tous les champs";
}
}
?>

<!DOCTYPE html>
<html lang="fr">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>JPO IUT de Meaux - Inscription Admin</title>
</head>
<body>
<div id="contener">
            <div>
                <form method="POST" action="">
                   
                                <input type="text" placeholder="login" name="login" id="login">

                                <input type="password" placeholder="Mot de passe" name="mdp" id="mdp">

                                <input type="password" placeholder="Confirmer le mot de passe" name="confirmmdp" id="confirmmdp">

                                <!-- <input type="text" placeholder="statut" name="statut" id="statut"> -->
                                 
         
                    <input type="submit" value="S'inscrire">

                </form>

           
            </div>
    </div>
</body>
</html>